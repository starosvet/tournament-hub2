import { Link, useLocation } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Search, User, LogOut, Trophy } from 'lucide-react';

export default function Header() {
  const { state, logout, isAdmin } = useApp();
  const location = useLocation();
  const user = state.currentUser;

  const navLinks = [
    { path: '/', label: 'Турниры' },
    { path: '/participants', label: 'Участники' },
    { path: '/history', label: 'История' },
    ...(isAdmin() ? [{ path: '/admin', label: 'Admin' }] : []),
  ];

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-[#e8e8e8]">
      <div className="max-w-[1200px] mx-auto px-4 h-[52px] flex items-center gap-5">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-1.5 text-[#dd0000] text-lg font-semibold whitespace-nowrap no-underline">
          <Trophy className="w-5 h-5" />
          <span className="text-black">Tournament Hub</span>
        </Link>

        {/* Navigation */}
        <nav className="flex gap-1 flex-1">
          {navLinks.map(link => {
            const isActive = location.pathname === link.path;
            return (
              <Link
                key={link.path}
                to={link.path}
                className={`px-4 py-2 text-sm rounded-lg transition-all duration-200 no-underline ${
                  isActive
                    ? 'text-black border-b-2 border-[#dd0000]'
                    : 'text-[#666] hover:text-black'
                }`}
              >
                {link.label}
              </Link>
            );
          })}
        </nav>

        {/* Right side */}
        <div className="flex items-center gap-3">
          <button className="p-2 text-[#999] hover:text-black transition-colors">
            <Search className="w-4 h-4" />
          </button>

          {user ? (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full border border-[#e8e8e8] bg-[#f7f7f7] flex items-center justify-center overflow-hidden">
                {user.avatar ? (
                  <img src={user.avatar} alt={user.username} className="w-full h-full object-cover" />
                ) : (
                  <User className="w-4 h-4 text-[#999]" />
                )}
              </div>
              <span className="text-sm text-[#666] hidden sm:block">{user.username}</span>
              <button
                onClick={logout}
                className="p-1.5 text-[#999] hover:text-[#dd0000] transition-colors"
                title="Выйти"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <Link to="/login" className="text-sm text-[#dd0000] hover:text-[#ff0000] no-underline">
              Войти
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
