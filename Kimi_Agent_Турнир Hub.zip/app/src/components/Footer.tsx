import { Link } from 'react-router-dom';
import { Trophy, ExternalLink } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-white border-t border-[#e8e8e8] mt-auto">
      <div className="max-w-[1200px] mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-6">
          {/* About */}
          <div>
            <div className="flex items-center gap-1.5 mb-3">
              <Trophy className="w-4 h-4 text-[#dd0000]" />
              <span className="font-semibold text-black text-sm">Tournament Hub</span>
            </div>
            <p className="text-xs text-[#999] leading-relaxed">
              Платформа для проведения аниме-турниров. Голосуйте за любимых персонажей, 
              аниме и открытия в формате захватывающих турнирных сеток.
            </p>
          </div>

          {/* Links */}
          <div>
            <h3 className="text-xs font-semibold text-black mb-3 uppercase tracking-wide">Ссылки</h3>
            <div className="flex flex-col gap-2">
              <Link to="/" className="text-xs text-[#666] hover:text-[#dd0000] no-underline transition-colors">Турниры</Link>
              <Link to="/participants" className="text-xs text-[#666] hover:text-[#dd0000] no-underline transition-colors">Участники</Link>
              <Link to="/history" className="text-xs text-[#666] hover:text-[#dd0000] no-underline transition-colors">История</Link>
            </div>
          </div>

          {/* Social */}
          <div>
            <h3 className="text-xs font-semibold text-black mb-3 uppercase tracking-wide">Мы в соцсетях</h3>
            <div className="flex gap-3">
              <a href="#" className="text-xs text-[#666] hover:text-[#dd0000] no-underline transition-colors flex items-center gap-1">
                VK <ExternalLink className="w-3 h-3" />
              </a>
              <a href="#" className="text-xs text-[#666] hover:text-[#dd0000] no-underline transition-colors flex items-center gap-1">
                Telegram <ExternalLink className="w-3 h-3" />
              </a>
              <a href="#" className="text-xs text-[#666] hover:text-[#dd0000] no-underline transition-colors flex items-center gap-1">
                Discord <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-[#e8e8e8] pt-4 text-center">
          <p className="text-xs text-[#999]">© Tournament Hub 2025</p>
        </div>
      </div>
    </footer>
  );
}
