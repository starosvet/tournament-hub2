import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { LogIn, Shield } from 'lucide-react';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useApp();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isAdmin, setIsAdmin] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!username.trim()) {
      setError('Введите имя пользователя');
      return;
    }

    if (isAdmin && !password) {
      setError('Введите пароль администратора');
      return;
    }

    const success = login(username, isAdmin ? password : undefined);
    if (success) {
      navigate('/');
    } else {
      setError('Неверный пароль');
    }
  };

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="w-full max-w-[360px]">
        <div className="bg-white border border-[#e8e8e8] rounded-lg shadow-sm p-6">
          <div className="flex items-center gap-2 mb-6">
            {isAdmin ? (
              <Shield className="w-5 h-5 text-[#dd0000]" />
            ) : (
              <LogIn className="w-5 h-5 text-[#dd0000]" />
            )}
            <h2 className="text-lg font-semibold text-black">
              {isAdmin ? 'Панель администратора' : 'Вход'}
            </h2>
          </div>

          {error && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded text-sm text-red-600">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm text-[#666] mb-1">Имя пользователя</label>
              <input
                type="text"
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full px-3 py-2 border border-[#e8e8e8] rounded text-sm focus:outline-none focus:border-[#dd0000] transition-colors"
                placeholder="Введите имя"
              />
            </div>

            {isAdmin && (
              <div>
                <label className="block text-sm text-[#666] mb-1">Пароль</label>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-[#e8e8e8] rounded text-sm focus:outline-none focus:border-[#dd0000] transition-colors"
                  placeholder="Введите пароль"
                />
              </div>
            )}

            <button
              type="submit"
              className="w-full py-2.5 bg-[#dd0000] text-white rounded text-sm font-medium hover:bg-[#ff0000] hover:shadow-[0_0_15px_rgba(221,0,0,0.3)] transition-all cursor-pointer"
            >
              {isAdmin ? 'Войти как админ' : 'Войти'}
            </button>
          </form>

          <div className="mt-4 pt-4 border-t border-[#e8e8e8] text-center">
            <button
              onClick={() => { setIsAdmin(!isAdmin); setError(''); }}
              className="text-xs text-[#999] hover:text-[#dd0000] transition-colors bg-none border-none cursor-pointer"
            >
              {isAdmin ? '← Обычный вход' : 'Вход для администратора →'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
