import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import {
  Trophy, ChevronLeft, ChevronRight,
  Check, X, Swords
} from 'lucide-react';

export default function TournamentDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { state, dispatch } = useApp();
  const tournament = state.tournaments.find(t => t.id === id);
  const [selectedRound, setSelectedRound] = useState(0);
  const [selectedMatch, setSelectedMatch] = useState(0);
  if (!tournament) {
    return (
      <div className="max-w-[1200px] mx-auto px-4 py-16 text-center">
        <Trophy className="w-16 h-16 text-[#e8e8e8] mx-auto mb-4" />
        <h2 className="text-xl text-[#999] mb-2">Турнир не найден</h2>
        <button onClick={() => navigate('/')} className="text-[#dd0000] hover:underline">
          ← Вернуться к списку
        </button>
      </div>
    );
  }

  const round = tournament.rounds[selectedRound];
  const match = round?.matches[selectedMatch];
  const hasVoted = match ? state.votes[match.id] : false;

  const handleVote = (matchId: string, choice: 'a' | 'b') => {
    if (!match || match.done) return;
    dispatch({ type: 'VOTE', matchId, choice, tournamentId: tournament.id });
  };

  const handleNextMatch = () => {
    if (!round) return;
    setSelectedMatch(prev => (prev + 1) % round.matches.length);
  };

  const handlePrevMatch = () => {
    if (!round) return;
    setSelectedMatch(prev => (prev - 1 + round.matches.length) % round.matches.length);
  };

  // Calculate rankings based on wins
  const rankings = [...tournament.participants].map(p => {
    const wins = tournament.rounds.reduce((w, r) => {
      return w + r.matches.filter(m => m.done && ((m.winner === 'a' && m.a.id === p.id) || (m.winner === 'b' && m.b.id === p.id))).length;
    }, 0);
    return { ...p, wins };
  }).sort((a, b) => b.wins - a.wins);

  // Top 4 for results
  const top4 = rankings.slice(0, 4);

  return (
    <div className="max-w-[1200px] mx-auto px-4 py-6">
      {/* Breadcrumb */}
      <div className="text-sm text-[#999] mb-4">
        <button onClick={() => navigate('/')} className="text-[#dd0000] hover:underline bg-none border-none cursor-pointer">
          Турниры
        </button>
        <span className="mx-2">/</span>
        <span>{tournament.name}</span>
      </div>

      {/* Title */}
      <div className="mb-6">
        <h1 className="text-[2rem] font-semibold text-black mb-3">{tournament.name}</h1>
        <div className="space-y-1">
          {tournament.rules.map((rule, i) => (
            <div key={i} className="flex items-start gap-2 text-sm text-[#666] leading-7">
              <span className="text-[#dd0000] mt-0">•</span>
              <span>{rule}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Round Navigation */}
      <div className="flex items-center gap-1 border-b border-[#e8e8e8] mb-6 overflow-x-auto">
        <button
          onClick={() => setSelectedRound(-1)}
          className={`px-4 py-2.5 text-sm whitespace-nowrap border-b-2 transition-colors bg-none cursor-pointer ${
            selectedRound === -1
              ? 'text-black border-black'
              : 'text-[#999] border-transparent hover:text-black'
          }`}
        >
          Результаты
        </button>
        {tournament.rounds.map((r, i) => (
          <button
            key={r.id}
            onClick={() => { setSelectedRound(i); setSelectedMatch(0); }}
            className={`px-4 py-2.5 text-sm whitespace-nowrap border-b-2 transition-colors bg-none cursor-pointer ${
              selectedRound === i
                ? 'text-black border-black'
                : 'text-[#999] border-transparent hover:text-black'
            }`}
          >
            {r.name}
          </button>
        ))}
      </div>

      {/* Main Content */}
      <div className="flex gap-6 flex-col lg:flex-row">
        {/* Left Content */}
        <div className="flex-1 min-w-0">
          {selectedRound === -1 ? (
            /* Results View */
            <div>
              {/* Top 4 */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                {top4.map((p, i) => (
                  <div
                    key={p.id}
                    className={`rounded-lg overflow-hidden bg-white border-2 ${
                      i === 0 ? 'border-[#f59e0b] shadow-[0_0_20px_rgba(245,158,11,0.3)]' :
                      i === 1 ? 'border-[#94a3b8]' :
                      i === 2 ? 'border-[#b45309]' :
                      'border-[#e8e8e8]'
                    }`}
                  >
                    <div className={`text-xs font-semibold px-3 py-1.5 text-white ${
                      i === 0 ? 'bg-[#f59e0b]' :
                      i === 1 ? 'bg-[#94a3b8]' :
                      i === 2 ? 'bg-[#b45309]' :
                      'bg-[#666]'
                    }`}>
                      {i + 1} МЕСТО
                    </div>
                    <div className="p-3">
                      <div className="aspect-[3/4] bg-[#f7f7f7] rounded mb-2 overflow-hidden">
                        {p.image ? (
                          <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-[#999] text-2xl">?</div>
                        )}
                      </div>
                      <div className="font-semibold text-sm text-black truncate">{p.name}</div>
                      {p.anime && <div className="text-xs text-[#999] truncate">{p.anime}</div>}
                    </div>
                  </div>
                ))}
              </div>

              {/* Full bracket */}
              <div className="bg-white border border-[#e8e8e8] rounded-lg p-4">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-black mb-4 px-2 py-2 bg-[#f7f7f7]">
                  Турнирная сетка
                </h3>
                <div className="overflow-x-auto">
                  <div className="flex gap-8 min-w-[600px]">
                    {tournament.rounds.map((r) => (
                      <div key={r.id} className="flex-1 min-w-[180px]">
                        <div className="text-xs font-semibold text-[#999] mb-3 text-center uppercase">
                          {r.name}
                        </div>
                        <div className="space-y-4 flex flex-col justify-around" style={{ minHeight: '200px' }}>
                          {r.matches.map(m => (
                            <div key={m.id} className="border border-[#e8e8e8] rounded p-2">
                              <div className={`flex items-center gap-1 text-xs ${m.winner === 'a' ? 'font-semibold text-black' : 'text-[#999]'}`}>
                                {m.winner === 'a' ? <Check className="w-3 h-3 text-[#22c55e]" /> : m.done ? <X className="w-3 h-3 text-[#999]" /> : <div className="w-3" />}
                                <span className="truncate flex-1">{m.a.name}</span>
                                {m.done && <span className="text-[10px]">{Math.round(m.votesA / (m.votesA + m.votesB) * 100)}%</span>}
                              </div>
                              <div className="flex items-center gap-1 text-xs mt-1 pt-1 border-t border-[#f7f7f7] ${m.winner === 'b' ? 'font-semibold text-black' : 'text-[#999]'}">
                                {m.winner === 'b' ? <Check className="w-3 h-3 text-[#22c55e]" /> : m.done ? <X className="w-3 h-3 text-[#999]" /> : <div className="w-3" />}
                                <span className="truncate flex-1">{m.b.name}</span>
                                {m.done && <span className="text-[10px]">{Math.round(m.votesB / (m.votesA + m.votesB) * 100)}%</span>}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : round && match ? (
            /* Match View */
            <div>
              {/* VS Match Card */}
              <div className="bg-white rounded-lg border border-[#e8e8e8] p-6 md:p-10 mb-6">
                {/* Round badge */}
                <div className="flex items-center justify-between mb-6">
                  <span className="bg-[#f7f7f7] text-[10px] font-semibold uppercase tracking-wider px-4 py-1.5">
                    {round.name}
                  </span>
                  {match.done && (
                    <span className="text-xs text-[#22c55e] font-medium flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Голосование завершено
                    </span>
                  )}
                </div>

                {/* Participants */}
                <div className="flex items-center justify-between gap-4 mb-8">
                  {/* Left arrow */}
                  <button
                    onClick={handlePrevMatch}
                    className="w-10 h-10 rounded-full border border-[#e8e8e8] flex items-center justify-center text-[#999] hover:border-[#dd0000] hover:text-[#dd0000] transition-colors flex-shrink-0 cursor-pointer bg-white"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>

                  {/* Participant A */}
                  <div className="flex-1 flex flex-col items-center text-center">
                    <div className="w-[160px] h-[220px] md:w-[200px] md:h-[280px] rounded-lg overflow-hidden bg-[#f7f7f7] mb-3">
                      {match.a.image ? (
                        <img src={match.a.image} alt={match.a.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-[#999] text-4xl font-bold">
                          {match.a.name[0] || '?'}
                        </div>
                      )}
                    </div>
                    <div className="font-semibold text-lg text-black">{match.a.name}</div>
                    {match.a.anime && <div className="text-sm text-[#999]">{match.a.anime}</div>}
                    {!match.done && (
                      <button
                        onClick={() => handleVote(match.id, 'a')}
                        disabled={!!hasVoted}
                        className={`mt-3 px-5 py-2 rounded text-sm font-medium transition-all cursor-pointer ${
                          hasVoted === 'a'
                            ? 'bg-[#22c55e] text-white'
                            : hasVoted
                            ? 'bg-[#e8e8e8] text-[#999] cursor-not-allowed'
                            : 'bg-[#dd0000] text-white hover:bg-[#ff0000] hover:shadow-[0_0_15px_rgba(221,0,0,0.3)]'
                        }`}
                      >
                        {hasVoted === 'a' ? '✓ Вы проголосовали' : `Голосовать за ${match.a.name}`}
                      </button>
                    )}
                  </div>

                  {/* VS */}
                  <div className="flex-shrink-0">
                    <div className="text-[2.5rem] md:text-[3rem] font-bold text-[#e8e8e8] select-none">
                      VS
                    </div>
                  </div>

                  {/* Participant B */}
                  <div className="flex-1 flex flex-col items-center text-center">
                    <div className="w-[160px] h-[220px] md:w-[200px] md:h-[280px] rounded-lg overflow-hidden bg-[#f7f7f7] mb-3">
                      {match.b.image ? (
                        <img src={match.b.image} alt={match.b.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-[#999] text-4xl font-bold">
                          {match.b.name[0] || '?'}
                        </div>
                      )}
                    </div>
                    <div className="font-semibold text-lg text-black">{match.b.name}</div>
                    {match.b.anime && <div className="text-sm text-[#999]">{match.b.anime}</div>}
                    {!match.done && (
                      <button
                        onClick={() => handleVote(match.id, 'b')}
                        disabled={!!hasVoted}
                        className={`mt-3 px-5 py-2 rounded text-sm font-medium transition-all cursor-pointer ${
                          hasVoted === 'b'
                            ? 'bg-[#22c55e] text-white'
                            : hasVoted
                            ? 'bg-[#e8e8e8] text-[#999] cursor-not-allowed'
                            : 'bg-[#dd0000] text-white hover:bg-[#ff0000] hover:shadow-[0_0_15px_rgba(221,0,0,0.3)]'
                        }`}
                      >
                        {hasVoted === 'b' ? '✓ Вы проголосовали' : `Голосовать за ${match.b.name}`}
                      </button>
                    )}
                  </div>

                  {/* Right arrow */}
                  <button
                    onClick={handleNextMatch}
                    className="w-10 h-10 rounded-full border border-[#e8e8e8] flex items-center justify-center text-[#999] hover:border-[#dd0000] hover:text-[#dd0000] transition-colors flex-shrink-0 cursor-pointer bg-white"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>

                {/* Vote bar */}
                {match && (match.votesA > 0 || match.votesB > 0) && (
                  <div>
                    <div className="flex justify-between text-sm text-[#666] mb-2">
                      <span>{(match.votesA / (match.votesA + match.votesB) * 100).toFixed(1)}% ({match.votesA})</span>
                      <span>{(match.votesB / (match.votesA + match.votesB) * 100).toFixed(1)}% ({match.votesB})</span>
                    </div>
                    <div className="h-2 bg-[#e8e8e8] rounded-full overflow-hidden flex">
                      <div
                        className="h-full bg-[#dd0000] transition-all duration-600"
                        style={{ width: `${match.votesA / (match.votesA + match.votesB) * 100}%` }}
                      />
                      <div
                        className="h-full bg-[#999] transition-all duration-600"
                        style={{ width: `${match.votesB / (match.votesA + match.votesB) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Rating */}
              <div className="bg-white border border-[#e8e8e8] rounded-lg mb-6">
                <div className="text-xs font-semibold uppercase tracking-wider text-black px-4 py-3 bg-[#f7f7f7] border-b border-[#e8e8e8]">
                  Рейтинг
                </div>
                <div className="divide-y divide-[#e8e8e8]">
                  {rankings.slice(0, 15).map((p, i) => (
                    <div key={p.id} className="flex items-center gap-3 px-4 py-2 hover:bg-[#f7f7f7] transition-colors">
                      <span className="text-sm text-[#999] w-6 text-right">{i + 1}.</span>
                      <span className="text-sm text-black flex-1">{p.name}</span>
                      <span className="text-xs text-[#999]">{p.wins}W</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Previous round results */}
              {selectedRound > 0 && (
                <div className="bg-white border border-[#e8e8e8] rounded-lg">
                  <div className="flex items-center justify-between px-4 py-3 bg-[#f7f7f7] border-b border-[#e8e8e8]">
                    <span className="text-xs font-semibold uppercase tracking-wider text-black">
                      В прошлом раунде
                    </span>
                    <button
                      onClick={() => setSelectedRound(selectedRound - 1)}
                      className="text-xs text-[#dd0000] hover:underline bg-none border-none cursor-pointer"
                    >
                      {tournament.rounds[selectedRound - 1]?.name} →
                    </button>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
                    {tournament.rounds[selectedRound - 1]?.matches.map(m => (
                      <div key={m.id} className="flex items-center gap-2 px-4 py-2 hover:bg-[#f7f7f7] transition-colors">
                        {m.winner === 'a' ? (
                          <Check className="w-3.5 h-3.5 text-[#22c55e]" />
                        ) : (
                          <X className="w-3.5 h-3.5 text-[#999]" />
                        )}
                        <span className="text-xs text-[#666]">
                          {Math.round(m.votesA / (m.votesA + m.votesB) * 100)}%
                        </span>
                        <span className="text-sm text-black flex-1">{m.a.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-12 text-[#999]">
              <Swords className="w-12 h-12 mx-auto mb-4 text-[#e8e8e8]" />
              <p>В этом раунде пока нет матчей</p>
            </div>
          )}
        </div>

        {/* Sidebar */}
        <aside className="w-full lg:w-[300px] flex-shrink-0 space-y-4">
          {/* Tournament Status */}
          <div className="bg-[#f7f7f7] border border-[#e8e8e8]">
            <div className="text-xs font-semibold uppercase tracking-wider text-black px-4 py-3 border-b border-[#e8e8e8]">
              Статус турнира
            </div>
            <div className="p-4">
              <div className="text-sm text-[#666] mb-2">
                {tournament.status === 'active' ? '🔥 Активно' :
                 tournament.status === 'completed' ? '✅ Завершено' :
                 tournament.status === 'nominating' ? '📝 Приём кандидатов' : '⏳ Скоро'}
              </div>
              <button
                onClick={() => setSelectedRound(-1)}
                className="text-sm text-[#dd0000] hover:underline bg-none border-none cursor-pointer"
              >
                К результатам →
              </button>
            </div>
          </div>

          {/* Conditions */}
          <div className="bg-[#f7f7f7] border border-[#e8e8e8]">
            <div className="text-xs font-semibold uppercase tracking-wider text-black px-4 py-3 border-b border-[#e8e8e8]">
              Условия турнира
            </div>
            <div className="p-4 text-sm text-[#666]">
              {tournament.type === 'single_elimination' ? 'Олимпийская система' : 'Швейцарская система'}
            </div>
          </div>

          {/* Participants count */}
          <div className="bg-[#f7f7f7] border border-[#e8e8e8]">
            <div className="text-xs font-semibold uppercase tracking-wider text-black px-4 py-3 border-b border-[#e8e8e8]">
              Участники
            </div>
            <div className="p-4 text-sm text-[#666]">
              {tournament.participants.length} пользователей
            </div>
          </div>

          {/* Participants grid */}
          <div className="bg-[#f7f7f7] border border-[#e8e8e8]">
            <div className="flex items-center justify-between px-4 py-3 border-b border-[#e8e8e8]">
              <span className="text-xs font-semibold uppercase tracking-wider text-black">
                Кандидаты
              </span>
              <span className="text-xs text-[#999]">{tournament.participants.length}</span>
            </div>
            <div className="p-3">
              <div className="grid grid-cols-6 gap-1">
                {tournament.participants.map(p => (
                  <div
                    key={p.id}
                    className="aspect-square rounded overflow-hidden bg-white border border-[#e8e8e8] hover:border-[#dd0000] transition-colors cursor-pointer"
                    title={p.name}
                  >
                    {p.image ? (
                      <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[10px] text-[#999]">
                        {p.name[0]}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
