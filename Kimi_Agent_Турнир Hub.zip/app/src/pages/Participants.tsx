import { useApp } from '@/context/AppContext';
import { Users } from 'lucide-react';

export default function Participants() {
  const { state } = useApp();
  const allParticipants = state.tournaments.flatMap(t => t.participants);
  const uniqueParticipants = allParticipants.filter((p, i, arr) => arr.findIndex(x => x.name === p.name) === i);

  return (
    <div className="max-w-[1200px] mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-[2.5rem] font-semibold text-black mb-2">Участники</h1>
        <p className="text-base text-[#999]">Все участники турниров</p>
      </div>

      {uniqueParticipants.length === 0 ? (
        <div className="text-center py-16">
          <Users className="w-12 h-12 text-[#e8e8e8] mx-auto mb-4" />
          <p className="text-[#999]">Пока нет участников</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {uniqueParticipants.map(p => (
            <div
              key={p.id}
              className="bg-white border border-[#e8e8e8] rounded-lg overflow-hidden hover:shadow-md hover:-translate-y-0.5 transition-all cursor-pointer"
            >
              <div className="aspect-[3/4] bg-[#f7f7f7] overflow-hidden">
                {p.image ? (
                  <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-[#999] text-3xl font-bold">
                    {p.name[0] || '?'}
                  </div>
                )}
              </div>
              <div className="p-3">
                <div className="font-medium text-sm text-black truncate">{p.name}</div>
                {p.anime && (
                  <div className="text-xs text-[#999] truncate mt-0.5">{p.anime}</div>
                )}
                {p.seiyuu && (
                  <div className="text-xs text-[#999] truncate">{p.seiyuu}</div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
