import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import type { Tournament, Participant } from '@/types';
import {
  Shield, Users, Trophy, SkipForward, Trash2,
  ChevronRight, AlertCircle
} from 'lucide-react';

export default function Admin() {
  const navigate = useNavigate();
  const { state, dispatch, isAdmin } = useApp();
  const [activeTab, setActiveTab] = useState<'tournaments' | 'participants' | 'control'>('tournaments');

  // Tournament creation form
  const [tourName, setTourName] = useState('');
  const [tourDesc, setTourDesc] = useState('');
  const [tourType, setTourType] = useState<'single_elimination' | 'swiss'>('single_elimination');
  const [tourStart, setTourStart] = useState('');
  const [tourDuration, setTourDuration] = useState(24);

  // Participant import
  const [importText, setImportText] = useState('');

  if (!isAdmin()) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center">
        <div className="text-center">
          <Shield className="w-12 h-12 text-[#e8e8e8] mx-auto mb-4" />
          <h2 className="text-xl text-[#999] mb-2">Доступ ограничен</h2>
          <p className="text-sm text-[#999] mb-4">Необходимо войти как администратор</p>
          <button
            onClick={() => navigate('/login')}
            className="px-4 py-2 bg-[#dd0000] text-white rounded text-sm hover:bg-[#ff0000] transition-colors cursor-pointer"
          >
            Войти
          </button>
        </div>
      </div>
    );
  }

  const handleCreateTournament = () => {
    if (!tourName.trim()) return;

    const now = new Date();
    const startDate = tourStart || now.toISOString().split('T')[0];
    const participants: Participant[] = [];

    // Generate rounds based on participant count (placeholder)
    const maxRounds = 6;
    const rounds = Array.from({ length: maxRounds }, (_, i) => ({
      id: i,
      name: i === maxRounds - 1 ? 'Финал' : i === maxRounds - 2 ? '1/2 финала' : i === maxRounds - 3 ? '1/4 финала' : i === maxRounds - 4 ? '1/8 финала' : `Раунд № ${i + 1}`,
      matches: [] as any[],
      startedAt: i === 0 ? now.toISOString() : null,
      endedAt: null,
      isActive: i === 0,
    }));

    const tournament: Tournament = {
      id: `tour_${Date.now()}`,
      name: tourName,
      description: tourDesc,
      rules: [],
      type: tourType,
      status: 'active',
      startDate,
      voteDurationHours: tourDuration,
      currentRound: 0,
      rounds,
      participants,
      config: {
        allowNominations: true,
        nominationDurationDays: 7,
        maxParticipants: 64,
        requireAuth: false,
      },
    };

    dispatch({ type: 'CREATE_TOURNAMENT', tournament });
    setTourName('');
    setTourDesc('');
    setTourStart('');
    setTourDuration(24);
  };

  const handleImportParticipants = () => {
    const lines = importText.trim().split('\n');
    const participants: Participant[] = lines.map((line, i) => {
      const parts = line.split('|').map(p => p.trim());
      return {
        id: `p_${Date.now()}_${i}`,
        name: parts[0] || `Участник ${i + 1}`,
        image: parts[1] || '',
        description: parts[2] || '',
        anime: parts[3] || '',
        wins: 0,
        losses: 0,
      };
    });

    // Add to the active tournament
    const activeTour = state.tournaments.find(t => t.status === 'active');
    if (activeTour) {
      dispatch({ type: 'ADD_PARTICIPANTS', tournamentId: activeTour.id, participants });
    }
    setImportText('');
  };

  const handleNextRound = (tournamentId: string) => {
    dispatch({ type: 'NEXT_ROUND', tournamentId });
  };

  const handleDeleteTournament = (id: string) => {
    if (window.confirm('Удалить этот турнир?')) {
      dispatch({ type: 'DELETE_TOURNAMENT', tournamentId: id });
    }
  };

  return (
    <div className="max-w-[1200px] mx-auto px-4 py-6">
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <Shield className="w-5 h-5 text-[#dd0000]" />
        <h1 className="text-2xl font-semibold text-black">Панель администратора</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-[#e8e8e8] mb-6">
        {[
          { key: 'tournaments' as const, label: '🏆 Турниры' },
          { key: 'participants' as const, label: '👥 Участники' },
          { key: 'control' as const, label: '🎮 Управление' },
        ].map(tab => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`px-4 py-2.5 text-sm border-b-2 transition-colors bg-none cursor-pointer ${
              activeTab === tab.key
                ? 'text-black border-black'
                : 'text-[#999] border-transparent hover:text-black'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tournaments Tab */}
      {activeTab === 'tournaments' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Create Tournament */}
          <div className="bg-white border border-[#e8e8e8] rounded-lg p-5">
            <h3 className="text-base font-semibold text-black mb-4 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-[#dd0000]" />
              Создать турнир
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-[#666] mb-1">Название</label>
                <input
                  type="text"
                  value={tourName}
                  onChange={e => setTourName(e.target.value)}
                  className="w-full px-3 py-2 border border-[#e8e8e8] rounded text-sm focus:outline-none focus:border-[#dd0000]"
                  placeholder="Название турнира"
                />
              </div>
              <div>
                <label className="block text-sm text-[#666] mb-1">Описание</label>
                <textarea
                  value={tourDesc}
                  onChange={e => setTourDesc(e.target.value)}
                  className="w-full px-3 py-2 border border-[#e8e8e8] rounded text-sm focus:outline-none focus:border-[#dd0000] h-20 resize-none"
                  placeholder="Описание и правила"
                />
              </div>
              <div>
                <label className="block text-sm text-[#666] mb-1">Тип</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input
                      type="radio"
                      value="single_elimination"
                      checked={tourType === 'single_elimination'}
                      onChange={() => setTourType('single_elimination')}
                    />
                    Олимпийская система
                  </label>
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input
                      type="radio"
                      value="swiss"
                      checked={tourType === 'swiss'}
                      onChange={() => setTourType('swiss')}
                    />
                    Швейцарская система
                  </label>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-[#666] mb-1">Дата начала</label>
                  <input
                    type="date"
                    value={tourStart}
                    onChange={e => setTourStart(e.target.value)}
                    className="w-full px-3 py-2 border border-[#e8e8e8] rounded text-sm focus:outline-none focus:border-[#dd0000]"
                  />
                </div>
                <div>
                  <label className="block text-sm text-[#666] mb-1">Длительность (часов)</label>
                  <input
                    type="number"
                    value={tourDuration}
                    onChange={e => setTourDuration(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-[#e8e8e8] rounded text-sm focus:outline-none focus:border-[#dd0000]"
                    min={1}
                    max={72}
                  />
                </div>
              </div>
              <button
                onClick={handleCreateTournament}
                className="w-full py-2.5 bg-[#dd0000] text-white rounded text-sm font-medium hover:bg-[#ff0000] hover:shadow-[0_0_15px_rgba(221,0,0,0.3)] transition-all cursor-pointer"
              >
                ✨ Создать турнир
              </button>
            </div>
          </div>

          {/* Tournament List */}
          <div className="bg-white border border-[#e8e8e8] rounded-lg p-5">
            <h3 className="text-base font-semibold text-black mb-4 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-[#dd0000]" />
              Список турниров
            </h3>
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {state.tournaments.map(t => (
                <div key={t.id} className="flex items-center gap-3 p-3 border border-[#e8e8e8] rounded hover:bg-[#f7f7f7] transition-colors">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-black truncate">{t.name}</div>
                    <div className="text-xs text-[#999]">
                      {t.status === 'active' ? '🔥 Активно' : '✅ Завершено'} • {t.participants.length} участников
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => navigate(`/contests/${t.id}`)}
                      className="p-1.5 text-[#999] hover:text-[#dd0000] transition-colors cursor-pointer"
                      title="Открыть"
                    >
                      <ChevronRight className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteTournament(t.id)}
                      className="p-1.5 text-[#999] hover:text-red-500 transition-colors cursor-pointer"
                      title="Удалить"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
              {state.tournaments.length === 0 && (
                <div className="text-center py-8 text-[#999] text-sm">Нет турниров</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Participants Tab */}
      {activeTab === 'participants' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Import */}
          <div className="bg-white border border-[#e8e8e8] rounded-lg p-5">
            <h3 className="text-base font-semibold text-black mb-4 flex items-center gap-2">
              <Users className="w-4 h-4 text-[#dd0000]" />
              Участники
            </h3>
            <p className="text-xs text-[#999] mb-2">Формат: Имя | URL изображения | Описание | Аниме (каждый с новой строки)</p>
            <textarea
              value={importText}
              onChange={e => setImportText(e.target.value)}
              className="w-full px-3 py-2 border border-[#e8e8e8] rounded text-sm focus:outline-none focus:border-[#dd0000] h-32 resize-none mb-3"
              placeholder="Аскеладд | https://... | Лидер наёмников | Vinland Saga&#10;Сайтама | https://... | Сильнейший герой | One Punch Man"
            />
            <div className="flex gap-2">
              <button
                onClick={handleImportParticipants}
                className="flex-1 py-2 bg-[#dd0000] text-white rounded text-sm font-medium hover:bg-[#ff0000] transition-colors cursor-pointer"
              >
                📥 Импорт
              </button>
              <button
                onClick={() => setImportText('')}
                className="py-2 px-4 border border-red-200 text-red-500 rounded text-sm hover:bg-red-50 transition-colors cursor-pointer"
              >
                🗑 Очистить
              </button>
            </div>
          </div>

          {/* Participant list */}
          <div className="bg-white border border-[#e8e8e8] rounded-lg p-5">
            <h3 className="text-base font-semibold text-black mb-4">
              Список участников
            </h3>
            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {state.tournaments.flatMap(t => t.participants).map(p => (
                <div key={p.id} className="flex items-center gap-3 p-2 border border-[#e8e8e8] rounded hover:bg-[#f7f7f7] transition-colors">
                  <div className="w-8 h-8 rounded bg-[#f7f7f7] flex items-center justify-center overflow-hidden flex-shrink-0">
                    {p.image ? (
                      <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="text-xs text-[#999]">{p.name[0]}</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-black truncate">{p.name}</div>
                    {p.anime && <div className="text-xs text-[#999]">{p.anime}</div>}
                  </div>
                </div>
              ))}
              {state.tournaments.flatMap(t => t.participants).length === 0 && (
                <div className="text-center py-8 text-[#999] text-sm">Нет участников</div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Control Tab */}
      {activeTab === 'control' && (
        <div className="space-y-6">
          {state.tournaments.map(t => (
            <div key={t.id} className="bg-white border border-[#e8e8e8] rounded-lg p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="text-base font-semibold text-black">{t.name}</h3>
                  <p className="text-sm text-[#999]">
                    Статус: {t.status === 'active' ? '🔥 Активно' : '✅ Завершено'} • 
                    Раунд: {t.currentRound + 1} / {t.rounds.length}
                  </p>
                </div>
                <div className="flex gap-2">
                  {t.status === 'active' && (
                    <button
                      onClick={() => handleNextRound(t.id)}
                      className="flex items-center gap-1.5 px-4 py-2 bg-amber-500 text-white rounded text-sm font-medium hover:bg-amber-600 transition-colors cursor-pointer"
                    >
                      <SkipForward className="w-4 h-4" />
                      Следующий раунд
                    </button>
                  )}
                  <button
                    onClick={() => handleDeleteTournament(t.id)}
                    className="flex items-center gap-1.5 px-4 py-2 border border-red-200 text-red-500 rounded text-sm hover:bg-red-50 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    Удалить
                  </button>
                </div>
              </div>

              {/* Match table */}
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#e8e8e8]">
                      <th className="text-left py-2 px-3 text-[#666] font-medium">Участник А</th>
                      <th className="text-center py-2 px-3 text-[#666] font-medium">Голоса</th>
                      <th className="text-center py-2 px-3 text-[#666] font-medium">VS</th>
                      <th className="text-center py-2 px-3 text-[#666] font-medium">Голоса</th>
                      <th className="text-left py-2 px-3 text-[#666] font-medium">Участник Б</th>
                      <th className="text-center py-2 px-3 text-[#666] font-medium">Статус</th>
                    </tr>
                  </thead>
                  <tbody>
                    {t.rounds[t.currentRound]?.matches.map(m => (
                      <tr key={m.id} className="border-b border-[#f7f7f7] hover:bg-[#f7f7f7]">
                        <td className="py-2 px-3 font-medium">{m.a.name}</td>
                        <td className="py-2 px-3 text-center text-[#dd0000] font-medium">{m.votesA}</td>
                        <td className="py-2 px-3 text-center text-[#999]">vs</td>
                        <td className="py-2 px-3 text-center text-[#dd0000] font-medium">{m.votesB}</td>
                        <td className="py-2 px-3 font-medium">{m.b.name}</td>
                        <td className="py-2 px-3 text-center">
                          {m.done ? (
                            <span className="text-[#22c55e] text-xs flex items-center justify-center gap-1">
                              <AlertCircle className="w-3 h-3" /> Завершён
                            </span>
                          ) : (
                            <span className="text-amber-500 text-xs">Активен</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
          {state.tournaments.length === 0 && (
            <div className="text-center py-12 text-[#999]">
              <Trophy className="w-12 h-12 mx-auto mb-4 text-[#e8e8e8]" />
              <p>Нет турниров для управления</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
