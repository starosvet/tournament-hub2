import { Link } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { HistoryIcon, Trophy, Calendar } from 'lucide-react';

export default function History() {
  const { state } = useApp();
  const completed = state.tournaments.filter(t => t.status === 'completed');
  const active = state.tournaments.filter(t => t.status === 'active');

  return (
    <div className="max-w-[1200px] mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-[2.5rem] font-semibold text-black mb-2">История</h1>
        <p className="text-base text-[#999]">Прошедшие и текущие турниры</p>
      </div>

      {/* Active Tournaments */}
      {active.length > 0 && (
        <section className="mb-10">
          <h2 className="text-xs font-semibold uppercase tracking-wider text-black mb-4 px-4 py-2 bg-[#f7f7f7] border-b border-[#e8e8e8]">
            Текущие турниры
          </h2>
          <div className="space-y-3">
            {active.map(t => (
              <div key={t.id} className="bg-white border border-[#e8e8e8] rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <Link
                      to={`/contests/${t.id}`}
                      className="text-base font-semibold text-black hover:text-[#dd0000] no-underline transition-colors"
                    >
                      {t.name}
                    </Link>
                    <div className="flex items-center gap-4 mt-2 text-sm text-[#999]">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {t.startDate} – {t.endDate || '...'}
                      </span>
                      <span className="text-[#dd0000] font-medium">
                        Раунд {t.currentRound + 1} / {t.rounds.length}
                      </span>
                    </div>
                  </div>
                  <Link
                    to={`/contests/${t.id}`}
                    className="text-sm text-[#dd0000] hover:underline whitespace-nowrap"
                  >
                    Перейти →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Completed Tournaments */}
      <section>
        <h2 className="text-xs font-semibold uppercase tracking-wider text-black mb-4 px-4 py-2 bg-[#f7f7f7] border-b border-[#e8e8e8]">
          Завершённые турниры
        </h2>
        {completed.length === 0 ? (
          <div className="text-center py-16">
            <HistoryIcon className="w-12 h-12 text-[#e8e8e8] mx-auto mb-4" />
            <p className="text-[#999]">Пока нет завершённых турниров</p>
          </div>
        ) : (
          <div className="space-y-3">
            {completed.map(t => (
              <div key={t.id} className="bg-white border border-[#e8e8e8] rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <Link
                      to={`/contests/${t.id}`}
                      className="text-base font-semibold text-black hover:text-[#dd0000] no-underline transition-colors"
                    >
                      {t.name}
                    </Link>
                    <div className="flex items-center gap-4 mt-2 text-sm text-[#999]">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5" />
                        {t.startDate} – {t.endDate}
                      </span>
                      <span className="flex items-center gap-1 text-[#22c55e]">
                        <Trophy className="w-3.5 h-3.5" />
                        {t.participants.length} участников
                      </span>
                    </div>
                  </div>
                  <Link
                    to={`/contests/${t.id}`}
                    className="text-sm text-[#dd0000] hover:underline whitespace-nowrap"
                  >
                    Результаты →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
