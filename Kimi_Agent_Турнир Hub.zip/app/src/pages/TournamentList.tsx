import { Link } from 'react-router-dom';
import { useApp } from '@/context/AppContext';
import { Trophy, Calendar, ChevronRight, Users } from 'lucide-react';

export default function TournamentList() {
  const { state } = useApp();
  const { tournaments } = state;

  const active = tournaments.filter(t => t.status === 'active');
  const completed = tournaments.filter(t => t.status === 'completed');
  const upcoming = tournaments.filter(t => t.status === 'upcoming' || t.status === 'nominating');

  return (
    <div className="max-w-[1200px] mx-auto px-4 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-[2.5rem] font-semibold text-black mb-2">Турниры</h1>
        <p className="text-base text-[#999]">Список всех турниров сайта</p>
      </div>

      {/* Active Tournaments */}
      {active.length > 0 && (
        <section className="mb-10">
          {active.map(t => (
            <div
              key={t.id}
              className="border-2 border-[#dd0000] rounded-lg p-5 bg-white relative hover:shadow-md transition-shadow"
            >
              <div className="absolute top-4 right-4 bg-[#dd0000] text-white text-[10px] font-semibold px-3 py-1 uppercase tracking-wider">
                Активно
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-[#dd0000]/10 flex items-center justify-center flex-shrink-0">
                  <Trophy className="w-6 h-6 text-[#dd0000]" />
                </div>
                <div className="flex-1 min-w-0">
                  <Link
                    to={`/contests/${t.id}`}
                    className="text-lg font-semibold text-black hover:text-[#dd0000] no-underline transition-colors"
                  >
                    {t.name}
                  </Link>
                  <div className="flex items-center gap-4 mt-2 text-sm text-[#999]">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {t.startDate} – {t.endDate || '...'}
                    </span>
                    <span className="flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      {t.participants.length} участников
                    </span>
                    <span className="text-[#dd0000] font-medium">
                      Раунд {t.currentRound + 1} / {t.rounds.length}
                    </span>
                  </div>
                  {t.description && (
                    <p className="text-sm text-[#666] mt-2 line-clamp-2">{t.description}</p>
                  )}
                </div>
                <Link
                  to={`/contests/${t.id}`}
                  className="flex items-center gap-1 text-[#dd0000] hover:text-[#ff0000] text-sm font-medium no-underline transition-colors flex-shrink-0"
                >
                  Перейти <ChevronRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          ))}
        </section>
      )}

      {/* Upcoming */}
      {upcoming.length > 0 && (
        <section className="mb-10">
          <h2 className="text-xs font-semibold text-black uppercase tracking-wider mb-4 px-4 py-2 bg-[#f7f7f7] border-b border-[#e8e8e8]">
            Скоро начнётся
          </h2>
          <div className="space-y-0">
            {upcoming.map((t, i) => (
              <div
                key={t.id}
                className="flex items-center gap-4 py-3 px-4 border-b border-[#e8e8e8] hover:bg-[#f7f7f7] transition-colors"
              >
                <span className="text-sm text-[#999] w-6 text-right">{i + 1}.</span>
                <span className="text-sm text-[#999] w-[140px]">{t.startDate}</span>
                <Link
                  to={`/contests/${t.id}`}
                  className="text-base text-black hover:text-[#dd0000] no-underline transition-colors flex-1 truncate"
                >
                  {t.name}
                </Link>
                <span className="text-xs text-[#dd0000] font-medium uppercase">
                  {t.status === 'nominating' ? 'Приём кандидатов' : 'Скоро'}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Completed */}
      <section>
        <h2 className="text-xs font-semibold text-black uppercase tracking-wider mb-4 px-4 py-2 bg-[#f7f7f7] border-b border-[#e8e8e8]">
          Завершено
        </h2>
        <div className="space-y-0">
          {completed.length === 0 && active.length === 0 && upcoming.length === 0 && (
            <div className="text-center py-12">
              <Trophy className="w-12 h-12 text-[#e8e8e8] mx-auto mb-4" />
              <p className="text-[#999] mb-2">Пока нет турниров</p>
              <p className="text-sm text-[#999]">Создайте первый турнир в панели администратора</p>
            </div>
          )}
          {[...completed, ...active].map((t, i) => (
            <div
              key={t.id}
              className="flex items-center gap-4 py-3 px-4 border-b border-[#e8e8e8] hover:bg-[#f7f7f7] transition-colors"
            >
              <span className="text-sm text-[#999] w-6 text-right">{i + 1}.</span>
              <span className="text-sm text-[#999] w-[140px] flex-shrink-0">
                {t.startDate} – {t.endDate || '...'}
              </span>
              <Link
                to={`/contests/${t.id}`}
                className="text-base text-black hover:text-[#dd0000] no-underline transition-colors flex-1 truncate"
              >
                {t.name}
              </Link>
              {t.status === 'active' && (
                <span className="text-xs text-[#dd0000] font-medium uppercase">Активно</span>
              )}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
