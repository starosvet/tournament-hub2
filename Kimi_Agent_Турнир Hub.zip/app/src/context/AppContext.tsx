import React, { createContext, useContext, useReducer, useEffect } from 'react';
import type { AppState, Tournament, Participant, User } from '@/types';

const STORAGE_KEY = 'tournament_hub_v2';
const ADMIN_PASSWORD = 'admin123';

function loadState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return getInitialState();
}

function getInitialState(): AppState {
  const demoParticipants: Participant[] = [
    { id: 'p1', name: 'Аскеладд', image: 'https://desu.shikimori.one/system/images/original/92434c2d8f0d0eabd6c6b0a3a7f5e2c7c5d8b9a0.jpg?1654005004', description: 'Лидер отряда наёмников. Сын датчанина Олафа от рабыни-валлийки Лидии. Не отличается физической силой, но обладает опытом, умом и интуицией.', anime: 'Vinland Saga', seiyuu: 'Наoya Утида', wins: 0, losses: 0 },
    { id: 'p2', name: 'Сайтама', image: 'https://kawai.shikimori.one/system/images/original/f5d4e3c2b1a0987654321fedcba9876543210abc.jpg?1623456789', description: 'Главный протагонист и сильнейший герой из ныне живущих. Натренировав себя до сверхчеловеческого состояния, столкнулся с главной проблемой — теперь он настолько силён, что даже работа супергероя кажется ему скучной рутиной.', anime: 'One Punch Man', seiyuu: 'Макото Фурукава', wins: 0, losses: 0 },
    { id: 'p3', name: 'Казума Сато', image: 'https://dere.shikimori.one/system/images/original/a1b2c3d4e5f6789012345678901234567890abcd.jpg?1600000000', description: 'Семнадцатилетний хикикомори и NEET, который умер от страха, что его собьёт трактор. После смерти оказался в фэнтезийном мире.', anime: 'KonoSuba', seiyuu: 'Дзюнъя Эноки', wins: 0, losses: 0 },
    { id: 'p4', name: 'Торфинн', image: 'https://nyaa.shikimori.one/system/images/original/b2c3d4e5f6a7890123456789012345678901abcde.jpg?1610000000', description: 'Обычный исландский юноша, сын величайшего воина Торса. Мечтает попасть в Винланд — страну за морем, где нет войн и рабства.', anime: 'Vinland Saga', seiyuu: 'Юко Санпэй', wins: 0, losses: 0 },
    { id: 'p5', name: 'Миюки Сироганэ', image: 'https://desu.shikimori.one/system/images/original/c3d4e5f6a7b8901234567890123456789012abcdef.jpg?1590000000', description: 'Президент студенческого совета академии Сютин. Гениальный стратег, вышедший из простой семьи на вершину элитной школы.', anime: 'Kaguya-sama', seiyuu: 'Макото Фурукава', wins: 0, losses: 0 },
    { id: 'p6', name: 'Аратака Рэйгэн', image: 'https://kawai.shikimori.one/system/images/original/d4e5f6a7b8c9012345678901234567890123abcdef.jpg?1580000000', description: 'Самозваный экстрасенс, который на самом деле не обладает никакими сверхъестественными способностями, но является гениальным манипулятором.', anime: 'Mob Psycho 100', seiyuu: 'Такахиро Сакурай', wins: 0, losses: 0 },
    { id: 'p7', name: 'Субару Нацуки', image: 'https://dere.shikimori.one/system/images/original/e5f6a7b8c9d0123456789012345678901234abcdef.jpg?1570000000', description: 'Обычный старшеклассник, внезапно перенесённый в фэнтезийный мир. Обладает способностью "Возвращение смертью".', anime: 'Re:Zero', seiyuu: 'Юсукэ Кобаяси', wins: 0, losses: 0 },
    { id: 'p8', name: 'Сэнку Исигами', image: 'https://nyaa.shikimori.one/system/images/original/f6a7b8c9d0e1234567890123456789012345abcdef.jpg?1560000000', description: 'Гениальный учёный, пробудившийся после тысячелетней окаменелости. Его цель — восстановить цивилизацию с нуля.', anime: 'Dr. Stone', seiyuu: 'Юсукэ Кобаяси', wins: 0, losses: 0 },
  ];

  const demoTournament: Tournament = {
    id: 'demo-1',
    name: 'Любимый мужской персонаж из аниме 2015-2019 гг',
    description: 'Участвуют мужские персонажи, первое полноценное появление которых произошло в аниме 2015-2019 гг.',
    rules: [
      'не учитываются появления в рекламных спешлах, овашках и т. п.',
      'не учитывается незначительное короткое появление в более ранних аниме',
      'не участвуют персонажи ремейков',
      'подходят персонажи из вечных длинных онгоингов',
    ],
    type: 'single_elimination',
    status: 'active',
    startDate: '2026-04-20',
    endDate: '2026-05-30',
    voteDurationHours: 24,
    currentRound: 0,
    participants: demoParticipants,
    rounds: [
      {
        id: 0,
        name: 'Раунд № 1',
        startedAt: '2026-04-20T00:00:00Z',
        endedAt: null,
        isActive: true,
        matches: [
          { id: 'm1', a: demoParticipants[0], b: demoParticipants[1], votesA: 2313, votesB: 1358, winner: 'a', done: true, roundId: 0 },
          { id: 'm2', a: demoParticipants[2], b: demoParticipants[3], votesA: 1245, votesB: 1876, winner: 'b', done: true, roundId: 0 },
          { id: 'm3', a: demoParticipants[4], b: demoParticipants[5], votesA: 1567, votesB: 1432, winner: 'a', done: true, roundId: 0 },
          { id: 'm4', a: demoParticipants[6], b: demoParticipants[7], votesA: 1987, votesB: 1023, winner: 'a', done: true, roundId: 0 },
        ],
      },
      {
        id: 1,
        name: 'Раунд № 2',
        startedAt: '2026-04-25T00:00:00Z',
        endedAt: null,
        isActive: true,
        matches: [
          { id: 'm5', a: demoParticipants[0], b: demoParticipants[3], votesA: 2100, votesB: 890, winner: null, done: false, roundId: 1 },
          { id: 'm6', a: demoParticipants[4], b: demoParticipants[6], votesA: 0, votesB: 0, winner: null, done: false, roundId: 1 },
        ],
      },
      {
        id: 2,
        name: 'Финал',
        startedAt: null,
        endedAt: null,
        isActive: false,
        matches: [
          { id: 'm7', a: { ...demoParticipants[0], id: 'tbd1', name: 'TBD', image: '' }, b: { ...demoParticipants[0], id: 'tbd2', name: 'TBD', image: '' }, votesA: 0, votesB: 0, winner: null, done: false, roundId: 2 },
        ],
      },
    ],
    config: {
      allowNominations: true,
      nominationDurationDays: 7,
      maxParticipants: 64,
      requireAuth: false,
    },
  };

  return {
    tournaments: [demoTournament],
    currentUser: null,
    votes: {},
  };
}

function saveState(state: AppState) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

type Action =
  | { type: 'SET_STATE'; payload: AppState }
  | { type: 'VOTE'; matchId: string; choice: 'a' | 'b'; tournamentId: string }
  | { type: 'CREATE_TOURNAMENT'; tournament: Tournament }
  | { type: 'UPDATE_TOURNAMENT'; tournament: Tournament }
  | { type: 'NEXT_ROUND'; tournamentId: string }
  | { type: 'LOGIN'; user: User }
  | { type: 'LOGOUT' }
  | { type: 'ADD_PARTICIPANTS'; tournamentId: string; participants: Participant[] }
  | { type: 'DELETE_TOURNAMENT'; tournamentId: string };

function reducer(state: AppState, action: Action): AppState {
  let newState: AppState;

  switch (action.type) {
    case 'SET_STATE':
      newState = action.payload;
      break;
    case 'VOTE': {
      const tIndex = state.tournaments.findIndex(t => t.id === action.tournamentId);
      if (tIndex === -1) return state;
      const tournaments = [...state.tournaments];
      const tournament = { ...tournaments[tIndex] };
      const rounds = [...tournament.rounds];
      const roundIndex = rounds.findIndex(r => r.isActive);
      if (roundIndex === -1) return state;
      const round = { ...rounds[roundIndex] };
      const matches = [...round.matches];
      const mIndex = matches.findIndex(m => m.id === action.matchId);
      if (mIndex === -1) return state;
      const match = { ...matches[mIndex] };

      if (action.choice === 'a') match.votesA++;
      else match.votesB++;

      matches[mIndex] = match;
      round.matches = matches;
      rounds[roundIndex] = round;
      tournament.rounds = rounds;
      tournaments[tIndex] = tournament;

      newState = {
        ...state,
        tournaments,
        votes: { ...state.votes, [action.matchId]: action.choice },
      };
      break;
    }
    case 'CREATE_TOURNAMENT':
      newState = { ...state, tournaments: [action.tournament, ...state.tournaments] };
      break;
    case 'UPDATE_TOURNAMENT': {
      const idx = state.tournaments.findIndex(t => t.id === action.tournament.id);
      if (idx === -1) return state;
      const updated = [...state.tournaments];
      updated[idx] = action.tournament;
      newState = { ...state, tournaments: updated };
      break;
    }
    case 'NEXT_ROUND': {
      const ti = state.tournaments.findIndex(t => t.id === action.tournamentId);
      if (ti === -1) return state;
      const t = { ...state.tournaments[ti] };
      const rs = t.rounds.map((r, i) => {
        if (i === t.currentRound) return { ...r, isActive: false, endedAt: new Date().toISOString() };
        if (i === t.currentRound + 1) return { ...r, isActive: true, startedAt: new Date().toISOString() };
        return r;
      });
      const allMatchesDone = t.rounds[t.currentRound]?.matches.every(m => m.done);
      if (!allMatchesDone) return state;
      newState = {
        ...state,
        tournaments: state.tournaments.map((tr, i) =>
          i === ti ? { ...t, rounds: rs, currentRound: Math.min(t.currentRound + 1, t.rounds.length - 1) } : tr
        ),
      };
      break;
    }
    case 'LOGIN':
      newState = { ...state, currentUser: action.user };
      break;
    case 'LOGOUT':
      newState = { ...state, currentUser: null };
      break;
    case 'ADD_PARTICIPANTS': {
      const tIdx = state.tournaments.findIndex(t => t.id === action.tournamentId);
      if (tIdx === -1) return state;
      const nt = [...state.tournaments];
      nt[tIdx] = { ...nt[tIdx], participants: [...nt[tIdx].participants, ...action.participants] };
      newState = { ...state, tournaments: nt };
      break;
    }
    case 'DELETE_TOURNAMENT':
      newState = { ...state, tournaments: state.tournaments.filter(t => t.id !== action.tournamentId) };
      break;
    default:
      return state;
  }

  saveState(newState);
  return newState;
}

interface ContextValue {
  state: AppState;
  dispatch: React.Dispatch<Action>;
  login: (username: string, password?: string) => boolean;
  logout: () => void;
  isAdmin: () => boolean;
}

const AppContext = createContext<ContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, null, loadState);

  useEffect(() => {
    saveState(state);
  }, [state]);

  const login = (username: string, password?: string): boolean => {
    if (password === ADMIN_PASSWORD) {
      dispatch({ type: 'LOGIN', user: { id: 'admin', username, isAdmin: true } });
      return true;
    }
    dispatch({ type: 'LOGIN', user: { id: `user_${Date.now()}`, username, isAdmin: false } });
    return true;
  };

  const logout = () => dispatch({ type: 'LOGOUT' });

  const isAdmin = () => state.currentUser?.isAdmin ?? false;

  return (
    <AppContext.Provider value={{ state, dispatch, login, logout, isAdmin }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
