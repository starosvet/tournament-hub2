import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppProvider } from '@/context/AppContext';
import Layout from '@/components/Layout';
import TournamentList from '@/pages/TournamentList';
import TournamentDetail from '@/pages/TournamentDetail';
import Login from '@/pages/Login';
import Admin from '@/pages/Admin';
import Participants from '@/pages/Participants';
import History from '@/pages/History';

function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <Routes>
          <Route element={<Layout />}>
            <Route path="/" element={<TournamentList />} />
            <Route path="/contests/:id" element={<TournamentDetail />} />
            <Route path="/login" element={<Login />} />
            <Route path="/admin" element={<Admin />} />
            <Route path="/participants" element={<Participants />} />
            <Route path="/history" element={<History />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AppProvider>
  );
}

export default App;
