export interface Participant {
  id: string;
  name: string;
  image: string;
  description?: string;
  anime?: string;
  seiyuu?: string;
  url?: string;
  seed?: number;
  wins: number;
  losses: number;
}

export interface Match {
  id: string;
  a: Participant;
  b: Participant;
  votesA: number;
  votesB: number;
  winner: 'a' | 'b' | null;
  done: boolean;
  roundId: number;
}

export interface Round {
  id: number;
  name: string;
  matches: Match[];
  startedAt: string | null;
  endedAt: string | null;
  isActive: boolean;
}

export type TournamentType = 'single_elimination' | 'swiss';
export type TournamentStatus = 'upcoming' | 'nominating' | 'active' | 'completed';

export interface Tournament {
  id: string;
  name: string;
  description: string;
  rules: string[];
  type: TournamentType;
  status: TournamentStatus;
  startDate: string;
  endDate?: string;
  voteDurationHours: number;
  currentRound: number;
  rounds: Round[];
  participants: Participant[];
  config: {
    allowNominations: boolean;
    nominationDurationDays: number;
    maxParticipants: number;
    requireAuth: boolean;
  };
}

export interface User {
  id: string;
  username: string;
  avatar?: string;
  isAdmin: boolean;
}

export interface AppState {
  tournaments: Tournament[];
  currentUser: User | null;
  votes: Record<string, 'a' | 'b'>;
}

export const ROUND_NAMES: Record<number, string> = {
  0: 'Раунд № 1',
  1: 'Раунд № 2',
  2: 'Раунд № 3',
  3: '1/8 финала',
  4: '1/4 финала',
  5: '1/2 финала',
  6: 'Финал',
};

export function getRoundName(roundIndex: number, totalRounds: number): string {
  if (roundIndex === totalRounds - 1) return 'Финал';
  if (roundIndex === totalRounds - 2) return '1/2 финала';
  if (roundIndex === totalRounds - 3) return '1/4 финала';
  if (roundIndex === totalRounds - 4) return '1/8 финала';
  return `Раунд № ${roundIndex + 1}`;
}
